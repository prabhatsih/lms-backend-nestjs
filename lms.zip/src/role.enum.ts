export enum Role {
    Admin = 'admin',
    Student = 'student',
    Teacher = 'teacher'
}