import { Body, Controller, Delete, Get, Param, Patch, Post, ValidationPipe } from '@nestjs/common';
import { TeacherService } from './teacher.service';
import { TeacherDto } from './dto/teacher.dto';
import { TeacherLoginDto } from './dto/teacherlogin.dto';
import { UpdateTeacherDto } from './dto/update.teacher.dto';
import { StudentService } from 'src/student/student.service';
import { StudentDto } from 'src/student/dto/student.dto';
import { BookService } from 'src/book/book.service';

@Controller('teacher')
export class TeacherController {

    constructor(private readonly teacherService: TeacherService,
                private readonly studentService: StudentService,
                private readonly bookService: BookService,
            ) {}

    @Post('sign-up')
    async teacherRegistration(@Body() teacherDto: TeacherDto) {
        return await this.teacherService.teacherRegistraion(teacherDto);
    }

    @Post('login')
    async teacherLogin(@Body(ValidationPipe) teacherLoginDto: TeacherLoginDto) {
        return await this.teacherService.teacherLogin(teacherLoginDto);
    }

    @Patch('update-teacher/:id')
    async updateTeacher(@Body() updateTeacherDto: UpdateTeacherDto, @Param('id') id: string) : Promise<any> {
        return await this.teacherService.updateTeacher(updateTeacherDto, id);
    }

    @Patch('teacher-login-pass/:id')
    async teacherUpdatePass(@Body() updateTeacherDto : UpdateTeacherDto, @Param('id') id:string) : Promise<any> {
        return await this.teacherService.teacherUpdatePass(updateTeacherDto, id);
    }

    @Delete('teacher-account-delete/:id')
    teacherAccountDelete(@Param('id') id:string) : Promise<any> {
        return this.teacherService.teacherAccountDelete(id);
    }

    @Post('register-student')
    async registerStudent(@Body() studentDto: StudentDto){
        return await this.studentService.registerStudent(studentDto);
    }

    @Get('search-book')
    findAll(){
        return this.bookService.findAll()
    }

    @Get('view-order')
    viewOrder(){
        return this.bookService.viewOrder();
    }

}
