import { HttpException, HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Teacher, TeacherDocument } from './schema/Teacher';
import { Model } from 'mongoose';
import { TeacherDto } from './dto/teacher.dto';
import { TeacherLoginDto } from './dto/teacherlogin.dto';
import { compare } from 'bcrypt';
import { UpdateTeacherDto } from './dto/update.teacher.dto';
import { NotFoundError } from 'rxjs';

@Injectable()
export class TeacherService {

    constructor(@InjectModel(Teacher.name) private teacherModel: Model<TeacherDocument>) {}

    teacherRegistraion(teacherDto : TeacherDto) {
        const model = new this.teacherModel();
        model.name = teacherDto.name;
        model.email = teacherDto.email;
        model.password = teacherDto.password;
        return model.save();
    }

    async teacherLogin(teacherLoginDto: TeacherLoginDto) {
        const user = await this.teacherModel.findOne({email: teacherLoginDto.email})

        if(!user){
            throw new HttpException('User Not Found', HttpStatus.UNPROCESSABLE_ENTITY)
        }

        const isPasswordCorrect = await compare(teacherLoginDto.password, user.password)

        if(!isPasswordCorrect){
            throw new HttpException("Password Not Matched", HttpStatus.UNPROCESSABLE_ENTITY)
        }

        return user;
    }

    async updateTeacher(updateTeacherDto : UpdateTeacherDto, id : string) : Promise<any> {
        // return "Update Teacher Data Successfully"
        const existingTeacher = await this.teacherModel.findById({_id: id})

        if(!existingTeacher) {
            throw new NotFoundException('Teacher Account Not found')
        }

        Object.assign(existingTeacher, updateTeacherDto)

        await existingTeacher.save();

        return {
            message : "Update Successfully",
            teacher: existingTeacher
        }
    }

    async teacherUpdatePass(updateTeacherDto: UpdateTeacherDto, id:string) : Promise<any> {
        // return await "Teacher Login Password Change Successfully"
        const existingTeacher = await this.teacherModel.findById({_id:id})

        if(!existingTeacher) {
            throw new NotFoundException('Teacher Account Not found')
        }

        existingTeacher.password = updateTeacherDto.password;

        await existingTeacher.save();

        return {
            message: "Update Teacher Login Password Change successfully",
            teacher: existingTeacher
        }
    }

    teacherAccountDelete(id : string) : Promise<any>{
        return this.teacherModel.deleteOne({ _id: id}).exec();
    }

    
}
