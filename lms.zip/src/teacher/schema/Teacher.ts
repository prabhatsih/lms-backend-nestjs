import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { hash } from "bcrypt";

export type TeacherDocument = Teacher & Document;

@Schema()
export class Teacher{
    @Prop()
    name: string;

    @Prop()
    email: string;

    @Prop()
    password: string;
}

export const TeacherSchema = SchemaFactory.createForClass(Teacher);

TeacherSchema.pre<Teacher>('save', async function (next: Function) {
    this.password = await hash(this.password, 10)
    next();
})