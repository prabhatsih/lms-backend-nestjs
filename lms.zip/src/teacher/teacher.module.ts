import { Module } from '@nestjs/common';
import { TeacherController } from './teacher.controller';
import { TeacherService } from './teacher.service';
import { MongooseModule } from '@nestjs/mongoose';
import { Teacher, TeacherSchema } from './schema/Teacher';
import { Student, StudentSchema } from 'src/student/schema/Student';
import { StudentService } from 'src/student/student.service';
import { Book, BookSchema } from 'src/book/schema/Book';
import { BookService } from 'src/book/book.service';
import { Order, OrderSchema } from 'src/book/schema/Order';

@Module({
  imports: [MongooseModule.forFeature([{name: Teacher.name, schema: TeacherSchema}]),
            MongooseModule.forFeature([{name: Student.name, schema: StudentSchema}]),
            MongooseModule.forFeature([{name: Book.name, schema: BookSchema}]),
            MongooseModule.forFeature([{name: Order.name, schema: OrderSchema}]),
          ],
  controllers: [TeacherController],
  providers: [TeacherService, StudentService, BookService]
})
export class TeacherModule {}
