import { PartialType } from "@nestjs/mapped-types";
import { TeacherDto } from "./teacher.dto";

export class UpdateTeacherDto extends PartialType(TeacherDto) {}