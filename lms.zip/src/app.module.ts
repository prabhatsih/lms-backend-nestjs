import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { AuthModule } from './student/student.module';
import { TeacherModule } from './teacher/teacher.module';
import { AdminModule } from './admin/admin.module';
import { BookModule } from './book/book.module';


@Module({
  imports: [
    // ConfigModule.forRoot({
    //   isGlobal: true,
    //   envFilePath : ['.env']
    // }),
    //   MongooseModule.forRootAsync({
    //   imports : [ConfigModule],
    //   useFactory: (configService: ConfigService) => ({uri: configService.get("MONGO_URI")}),
    //   inject: [ConfigService]
    // }),
    MongooseModule.forRoot("mongodb://localhost:27017/lms"),
    AuthModule,
    TeacherModule,
    AdminModule,
    BookModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
