import { HttpException, HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { Student, StudentDocument } from './schema/Student';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { StudentDto } from './dto/student.dto';
import { StudentLoginDto } from './dto/studentlogin.dto';
import { compare } from 'bcrypt';
import { UpdateStudentDto } from './dto/update-student';

@Injectable()
export class StudentService {

    constructor(@InjectModel(Student.name) private studentModel: Model<StudentDocument>) {}

    registerStudent(studentDto : StudentDto) : Promise<any>{
        const model = new this.studentModel();
        model.name = studentDto.name;
        model.mobile = studentDto.mobile;
        model.email = studentDto.email;
        model.password = studentDto.password;
        return model.save();
    }

    async loginStudent(studentLoginDto : StudentLoginDto) : Promise<any> {
        const user = await this.studentModel.findOne({email: studentLoginDto.email})
        // console.log(user," user")

        if(!user) {
            throw new HttpException('User Not found', HttpStatus.UNPROCESSABLE_ENTITY)
        }

        const isPasswordCorrect = await compare(studentLoginDto.password, user.password)
        // console.log("password", isPasswordCorrect)

        if(!isPasswordCorrect) {
            throw new HttpException('Incorrect Password', HttpStatus.UNPROCESSABLE_ENTITY)
        }

        return user
    }

    async updateStudent(updateStudentDto : UpdateStudentDto, id:string) : Promise<any> {
        // return await "Student Account Updated";
        const existingStudent = await this.studentModel.findById({_id : id});

        if(!existingStudent) {
            throw new NotFoundException('Student Data Not Found')
        }

        Object.assign(existingStudent, updateStudentDto)

        await existingStudent.save();

        return {
            message : "Student Data Updated Successfully",
            student: existingStudent
        }
    }

    async updateLoginPass(updateStudentDto: UpdateStudentDto, id : string) : Promise<any> {
        // return await "Student Account Password Change Successfully";
        const existingStudent = await this.studentModel.findById({_id : id})

        if(!existingStudent) {
            throw new NotFoundException('Student Data Not Found')
        }

        existingStudent.password = updateStudentDto.password;

        await existingStudent.save();

        return {
            message : "Student Login Password Change Successfully",
            student : existingStudent
        }
    }

    async studentAccountDelete(id : string) : Promise<any>{
        return await this.studentModel.deleteOne({_id:id}).exec();
    }

    

}
