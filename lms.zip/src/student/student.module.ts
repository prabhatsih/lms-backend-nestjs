import { Module } from '@nestjs/common';
import { StudentController } from './student.controller';
import { StudentService } from './student.service';
import { Mongoose } from 'mongoose';
import { MongooseModule } from '@nestjs/mongoose';
import { Student, StudentSchema } from './schema/Student';
import { Book, BookSchema } from 'src/book/schema/Book';
import { BookService } from 'src/book/book.service';
import { Order, OrderSchema } from 'src/book/schema/Order';


@Module({
  imports:[MongooseModule.forFeature([{name: Student.name, schema: StudentSchema}]),
           MongooseModule.forFeature([{name: Book.name, schema: BookSchema}]),
           MongooseModule.forFeature([{name: Order.name, schema: OrderSchema}])
          ],
  controllers: [StudentController],
  providers: [StudentService, BookService],
  // exports: [StudentService],
})
export class AuthModule {}
