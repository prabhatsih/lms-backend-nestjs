import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { hash } from "bcrypt";

export type StudentDocument = Student & Document;

@Schema()
export class Student {
    @Prop()
    name: string;

    @Prop()
    mobile: number;

    @Prop()
    email : string;

    @Prop()
    password: string;
}

export const StudentSchema = SchemaFactory.createForClass(Student);

StudentSchema.pre<Student>('save', async function (next: Function) {
    this.password = await hash(this.password, 10)
    next()
})