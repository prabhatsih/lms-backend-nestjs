import { Body, Controller, Delete, Get, Param, Patch, Post } from '@nestjs/common';
import { StudentService } from './student.service';
import { StudentDto } from './dto/student.dto';
import { StudentLoginDto } from './dto/studentlogin.dto';
import { BookService } from 'src/book/book.service';
import { UpdateStudentDto } from './dto/update-student';

@Controller('student')
export class StudentController {

    constructor(private readonly studentService: StudentService,
        private readonly bookService: BookService,
    ) { }

    @Post("registration")
    async registerStudent(@Body() studentDto: StudentDto): Promise<any> {
        // const user = await this.studentService.registerStudent(studentDto)
        //return user;
        return await this.studentService.registerStudent(studentDto)
    }

    @Post("login")
    async loginStudent(@Body() studentLoginDto: StudentLoginDto): Promise<any> {
        return await this.studentService.loginStudent(studentLoginDto)

    }

    @Patch('update-student/:id')
    async updateStudent(@Body() updateStudentDto: UpdateStudentDto, @Param('id') id:string): Promise<any> {
        return await this.studentService.updateStudent(updateStudentDto, id)
    }

    @Patch('student-login-pass/:id')
    async updateLoginPass(@Body() updateStudentDto: UpdateStudentDto, @Param('id') id:string): Promise<any> {
        return await this.studentService.updateLoginPass(updateStudentDto, id);
    }

    @Delete('delete-student:id')
    async studentAccountDelete(@Param('id') id: string): Promise<any> {
        return await this.studentService.studentAccountDelete(id);
    }

    @Get('search-book')
    findAll() {
        return this.bookService.findAll()
    }

    @Get('view-order')
    viewOrder() {
        return this.bookService.viewOrder()
    }
}
