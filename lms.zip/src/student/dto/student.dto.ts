import { IsEmail, IsMobilePhone, IsNotEmpty} from "class-validator"

export class StudentDto {
    
    @IsNotEmpty({message: "Name is Required"})
    name: string

    @IsMobilePhone()
    @IsNotEmpty({message: "Mobile Number is Required"})
    mobile: number

    @IsEmail()
    @IsNotEmpty({message: "Email is Required"})
    email: string

    @IsNotEmpty({message: "Password is Required"})
    password: string
    
}