import { IsEmail, IsNotEmpty } from "class-validator"

export class StudentLoginDto {
    @IsEmail()
    @IsNotEmpty({message: "Email is Required"})
    email: string

    @IsNotEmpty({message: "Password is Required"})
    password: string
}