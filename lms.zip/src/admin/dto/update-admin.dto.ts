import { PartialType } from '@nestjs/mapped-types';
import { CreateAdminDto } from './create-admin.dto';

export class UpdateAdminDto extends PartialType(CreateAdminDto) {}

// import { IsEmail, IsOptional } from "class-validator";

// export class UpdateAdminDto {
//     @IsOptional()
//     name: string;

//     @IsEmail()
//     @IsOptional()
//     email: string;

//     @IsOptional()
//     password: string;
// }

