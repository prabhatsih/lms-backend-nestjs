import { IsEmail, IsNotEmpty } from "class-validator";

export class CreateAdminDto {
    @IsNotEmpty({message: "Name is Required"})
    name: string;

    @IsEmail()
    @IsNotEmpty({message: "Email is Required"})
    email: string;

    @IsNotEmpty({message: "Password is Required"})
    password: string;
}
