import { IsEmail, IsEmpty } from "class-validator";

export class AdminLoginDto{
    @IsEmail()
    @IsEmpty({message: "Email is Required"})
    email: string;

    @IsEmpty({message: "Password is Required"})
    password: string;
}