import { Module } from '@nestjs/common';
import { AdminService } from './admin.service';
import { AdminController } from './admin.controller';
import { Mongoose } from 'mongoose';
import { MongooseModule } from '@nestjs/mongoose';
import { Admin, AdminSchema } from './schema/Admin';
import { Teacher, TeacherSchema } from 'src/teacher/schema/Teacher';
import { TeacherService } from 'src/teacher/teacher.service';
import { Student, StudentSchema } from 'src/student/schema/Student';
import { StudentService } from 'src/student/student.service';
import { BookService } from 'src/book/book.service';
import { Book, BookSchema } from 'src/book/schema/Book';
import { Order, OrderSchema } from 'src/book/schema/Order';

@Module({
  imports: [MongooseModule.forFeature([{name: Admin.name, schema:AdminSchema}]),
            MongooseModule.forFeature([{name: Teacher.name, schema:TeacherSchema}]),
            MongooseModule.forFeature([{name: Student.name, schema: StudentSchema}]),
            MongooseModule.forFeature([{name: Book.name, schema: BookSchema}]),
            MongooseModule.forFeature([{name: Order.name, schema: OrderSchema}]),
          ],
  controllers: [AdminController],
  providers: [AdminService, 
              TeacherService,
              StudentService,
              BookService
            ],
})
export class AdminModule {}
