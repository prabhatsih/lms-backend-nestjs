import { HttpException, HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { CreateAdminDto } from './dto/create-admin.dto';
import { UpdateAdminDto } from './dto/update-admin.dto';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { Admin, AdminDocument } from './schema/Admin';
import { AdminLoginDto } from './dto/adminlogin.dto';
import { compare } from 'bcrypt';
import { promises } from 'dns';
import { TeacherDto } from 'src/teacher/dto/teacher.dto';
import { Teacher, TeacherDocument } from 'src/teacher/schema/Teacher';

@Injectable()
export class AdminService {

  constructor(@InjectModel(Admin.name) private adminModel: Model<AdminDocument>,
    @InjectModel(Teacher.name) private teacherModel: Model<TeacherDocument>
  ) { }

  async createAdmin(createAdminDto: CreateAdminDto): Promise<any> {
    const model = new this.adminModel();
    model.name = createAdminDto.name;
    model.email = createAdminDto.email;
    model.password = createAdminDto.password;
    await model.save();
    return "Admin Registration Successfully"
  }

  async login(adminLoginDto: AdminLoginDto): Promise<any> {
    const user = await this.adminModel.findOne({ email: adminLoginDto.email })

    if (!user) {
      throw new HttpException('User Not Found', HttpStatus.UNPROCESSABLE_ENTITY)
    }

    const isPasswordCorrect = await compare(adminLoginDto.password, user.password)

    if (!isPasswordCorrect) {
      throw new HttpException('Password is not correct', HttpStatus.UNPROCESSABLE_ENTITY)
    }

    return user;
  }

  async updateAdminAccount(updateAdminDto: UpdateAdminDto, id: string): Promise<any> {
    // return "Update successfully"
    const existingAdmin = await this.adminModel.findById({ _id: id });

    if(!existingAdmin){
      throw new NotFoundException('Admin Account Not Found');
    }

    // console.log(existingAdmin);
    Object.assign(existingAdmin, updateAdminDto);

    await this.adminModel.updateOne({_id:id,updateAdminDto});

    return {
      message: 'Update successfully',
      admin: existingAdmin,
    };

  }

  async changeAdminPassword(updateAdminDto: UpdateAdminDto): Promise<any> {
    return await "Change Login Password"
  }

  remove(id: string): Promise<any> {
    return this.adminModel.deleteOne({ _id: id }).exec();
  }

  async signUpTeacher(createTeacherDto: TeacherDto): Promise<any> {
    const model = new this.teacherModel();
    model.name = createTeacherDto.name;
    model.email = createTeacherDto.email;
    model.password = createTeacherDto.password;
    return await model.save();
  }
}
