import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { AdminService } from './admin.service';
import { CreateAdminDto } from './dto/create-admin.dto';
import { UpdateAdminDto } from './dto/update-admin.dto';
import { AdminLoginDto } from './dto/adminlogin.dto';
import { TeacherService } from 'src/teacher/teacher.service';
import { TeacherDto } from 'src/teacher/dto/teacher.dto';
import { StudentDto } from 'src/student/dto/student.dto';
import { StudentService } from 'src/student/student.service';
import { CreateBookDto } from 'src/book/dto/create-book.dto';
import { BookService } from 'src/book/book.service';
import { UpdateBookDto } from 'src/book/dto/update-book.dto';

@Controller('admin')
export class AdminController {
  constructor(private readonly adminService: AdminService,
    private readonly teacherService: TeacherService,
    private readonly studentService: StudentService,
    private readonly bookService: BookService,
  ) { }

  @Post("registration")
  async createAdmin(@Body() createAdminDto: CreateAdminDto): Promise<any> {
    return await this.adminService.createAdmin(createAdminDto);
  }

  @Post("login")
  async login(@Body() adminLoginDto: AdminLoginDto): Promise<any> {
    return await this.adminService.login(adminLoginDto)
  }

  @Patch("update/:id")
  async updateAdminAccount(@Param('id') id: string, @Body() updateAdminDto: UpdateAdminDto): Promise<any> {
    return await this.adminService.updateAdminAccount(updateAdminDto, id);
  }


  @Post('change-password')
  async changeAdminPassword(@Body() updateAdminDto: UpdateAdminDto): Promise<any> {
    return await this.adminService.changeAdminPassword(updateAdminDto);
  }

  @Delete('/:id')
  async remove(@Param('id') id: string): Promise<any> {
    return this.adminService.remove(id);
  }

  @Post('teacher-registration')
  async signUpTeacher(@Body() teacherDto: TeacherDto): Promise<any> {
    return await this.adminService.signUpTeacher(teacherDto);
  }

  @Post('student-registration')
  async registerStudent(@Body() studentDto: StudentDto): Promise<any> {
    return await this.studentService.registerStudent(studentDto);
  }

  @Post('add-book')
  async createBook(@Body() createBookDto: CreateBookDto) {
    return await this.bookService.createBook(createBookDto);
  }

  @Patch('update-book')
  async updateBook(@Body() updateBookDto: UpdateBookDto, @Param('id') id:string) {
    return await this.bookService.updateBook(updateBookDto, id);
  }

  @Delete('delete-book:id')
  removeBook(@Param('id') id: string) {
    return this.bookService.removeBook(id);
  }

  @Get('search-book')
  findAll() {
    return this.bookService.findAll();
  }

  @Get('view-order')
  viewOrder() {
    return this.bookService.viewOrder();
  }

}


