import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Book, BookDocument } from './schema/Book';
import { Model } from 'mongoose';
import { CreateBookDto } from './dto/create-book.dto';
import { UpdateBookDto } from './dto/update-book.dto';
import { Order, OrderDocument } from './schema/Order';
import { Mode } from 'fs';

@Injectable()
export class BookService {

    constructor(@InjectModel(Book.name) private bookModel: Model<BookDocument>,
                @InjectModel(Order.name) private orderModel: Model<OrderDocument>
                ) { }

    async createBook(createBookDto: CreateBookDto) {
        const model = new this.bookModel();
        model.title = createBookDto.title;
        model.author = createBookDto.author;
        model.published = createBookDto.published;
        return await model.save();
    }

    async updateBook(updateBookDto: UpdateBookDto, id:string) : Promise<any> {
        // return await "Update Book Successfully"
        const existingBook:any = this.bookModel.findById({_id: id})

        if(!existingBook) {
            throw new NotFoundException('Book Data Not Found')
        }

        Object.assign(existingBook, updateBookDto)

        await existingBook.save();

        return {
            message : "Student Data Updated Successfully",
            student: existingBook
        }
    }

    findAll(): Promise<Book[]> {
        return this.bookModel.find().exec();
    }

    findOne(id: string): Promise<Book> {
        return this.bookModel.findById(id).exec();
    }

    removeBook(id: string) : Promise<any> {
        return this.bookModel.deleteOne({_id : id}).exec();
    }

    viewOrder(): Promise<Order[]> {
        return this.orderModel.find().exec();
    }
}
