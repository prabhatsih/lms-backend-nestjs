import { Module } from '@nestjs/common';
import { BookController } from './book.controller';
import { BookService } from './book.service';
import { MongooseModule } from '@nestjs/mongoose';
import { Book, BookSchema } from './schema/Book';
import { Order, OrderSchema } from './schema/Order';

@Module({
  imports: [MongooseModule.forFeature([{name: Book.name, schema: BookSchema}]),
            MongooseModule.forFeature([{name: Order.name, schema: OrderSchema}])
          ],
  controllers: [BookController],
  providers: [BookService]
})
export class BookModule {}
