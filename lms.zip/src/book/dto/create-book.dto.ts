import { IsNotEmpty } from "class-validator";

export class CreateBookDto{
    @IsNotEmpty({message: "Book Name is Required"})
    title: string;

    @IsNotEmpty({message: "Author Name is Required"})
    author: string;

    published: number;
}