import { IsNotEmpty } from "class-validator";

export class OrderBookDto{
    title: string;
    
    author: string;

    published: number;
}